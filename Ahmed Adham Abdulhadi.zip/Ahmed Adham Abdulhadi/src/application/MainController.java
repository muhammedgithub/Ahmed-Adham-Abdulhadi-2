package application;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;

public class MainController {
	
	@FXML
	private Label lbResult;
	@FXML
	private TextField t1, t2;
	
	@FXML
	private RadioButton addR, subR, mulR, divR;
	
	
	public void opSelect() {
		
		int n1 = Integer.parseInt(t1.getText());
		int n2 = Integer.parseInt(t2.getText());
		if(addR.isSelected())
		{	
			int res = MathOper.add(n1,n2);
			lbResult.setText(String.valueOf("The Result: " +res));
		
		}
		else if (subR.isSelected()) {
			int res = MathOper.sub(n1,n2);
			lbResult.setText(String.valueOf("The Result: "+res));
			
		}
			
	
		else if (mulR.isSelected()) {
			int res = MathOper.mul(n1,n2);
			lbResult.setText(String.valueOf("The Result: " +res));
		
		}
		else {
			int res = MathOper.div(n1,n2);
			lbResult.setText(String.valueOf("The Result: " +res));
		}
		
		}
}
