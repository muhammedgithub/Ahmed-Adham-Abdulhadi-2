package application;

import javax.swing.JOptionPane;

public class MathOper {
	
	public static int add(int t1, int t2)
	{
		return t1 + t2;
	}
	
	public static int sub(int t1, int t2)
	{
		return t1 - t2;
	}
	public static int mul(int t1, int t2)
	{
		return t1 * t2;
	}
	public static int div(int t1, int t2)
	{
		
		if (t2 != 0)
		{
		return t1 / t2;
		}
		
		else 
			{
			JOptionPane.showMessageDialog(null, "Error Div By Zero");
			return 0;
			}
	}
}
